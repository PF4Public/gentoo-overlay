// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef TOOLS_GN_NINJA_UTILS_H_
#define TOOLS_GN_NINJA_UTILS_H_

#include <string>

class BuildSettings;
class OutputFile;
class Settings;
class SourceFile;
class Target;

// Example: "base/base.ninja". The string version will not be escaped, and
// will always have slashes for path separators.
SourceFile GetNinjaFileForTarget(const Target* target);

// Returns the name of the root .ninja file for the given toolchain.
SourceFile GetNinjaFileForToolchain(const Settings* settings);

// Returns the prefix applied to the Ninja rules in a given toolchain so they
// don't collide with rules from other toolchains.
std::string GetNinjaRulePrefixForToolchain(const Settings* settings);

// Returns the name of the phony target (or stamp file) that depends on all
// hard deps of |target|. Only written if |target| has at least two hard deps,
// see NinjaTargetWriter::WriteHardDepsStampOrPhony().
OutputFile GetHardDepsOutputFile(const Target* target,
                                 const BuildSettings* build_settings);

// Returns the output file path for the target's public inputs stamp or phony
// target.
OutputFile GetPublicInputsOutputFile(const Target* target,
                                     const BuildSettings* build_settings);

#endif  // TOOLS_GN_NINJA_UTILS_H_
